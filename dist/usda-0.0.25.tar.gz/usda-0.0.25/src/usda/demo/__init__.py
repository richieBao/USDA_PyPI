# -*- coding: utf-8 -*-
"""
Created on Sun Aug 21 15:11:00 2022

@author: Richie Bao-caDesign设计(cadesign.cn)
"""
from ._demo_isotonic_regression import demo_isotonic_regression

__all__=[
    "demo_isotonic_regression",
    ]



