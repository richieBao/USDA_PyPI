# -*- coding: utf-8 -*-
"""
Created on Sun Aug 21 15:11:00 2022

@author: Richie Bao-caDesign设计(cadesign.cn)
"""
from ._manifold_learning_illustration import plot_embedding
from ._manifold_learning_illustration import manifold_learning_illustration

__all__=[
    "manifold_learning_illustration",
    "plot_embedding",
    ]



