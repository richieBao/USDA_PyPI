# -*- coding: utf-8 -*-
"""
Created on Sun Aug 21 15:11:00 2022

@author: Richie Bao-caDesign设计(cadesign.cn)
"""
from .random_walk import temporal_difference
from .random_walk import figure7_2

__all__=[
    "temporal_difference",
    "figure7_2",
    ]
