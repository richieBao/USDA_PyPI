# -*- coding: utf-8 -*-
"""
Created on Sun Aug 21 15:11:00 2022

@author: Richie Bao-caDesign设计(cadesign.cn)
"""
from .ten_armed_testbed import figure_2_1
from .ten_armed_testbed import Bandit
from .ten_armed_testbed import simulate
from .ten_armed_testbed import figure_2_2
from .ten_armed_testbed import figure_2_3
from .ten_armed_testbed import figure_2_4
from .ten_armed_testbed import figure_2_5

__all__=[
    "figure_2_1",
    "Bandit",
    "simulate",
    "figure_2_2",
    "figure_2_3",
    "figure_2_4",
    "figure_2_5",
    ]
