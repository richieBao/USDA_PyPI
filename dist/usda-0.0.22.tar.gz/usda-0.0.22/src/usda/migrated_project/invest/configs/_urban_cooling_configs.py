# -*- coding: utf-8 -*-
"""
Created on Fri Jun  9 20:57:21 2023

@author: richie bao
"""
TARGET_NODATA = -1

