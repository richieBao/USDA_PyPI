# -*- coding: utf-8 -*-
"""
Created on Sun Aug 21 15:11:00 2022

@author: Richie Bao-caDesign设计(cadesign.cn)
"""
if __package__:
    # from ._carbon_configs import cfg as cfg_carbon
    from . import _carbon_configs as cfg_carbon
else:
    import _carbon_configs as cfg_carbon



__all__ = [
    'cfg_carbon',
    ]

