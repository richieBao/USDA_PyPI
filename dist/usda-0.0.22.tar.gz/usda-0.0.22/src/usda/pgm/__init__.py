# -*- coding: utf-8 -*-
"""
Created on Sun Aug 21 15:11:00 2022

@author: Richie Bao-caDesign设计(cadesign.cn)
"""
from ._probability_theory import P_Xk_binomialDistribution

__all__ = [
    "P_Xk_binomialDistribution",
    ]
