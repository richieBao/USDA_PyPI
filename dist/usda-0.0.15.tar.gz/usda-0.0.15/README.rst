.. -*- mode: rst -*-

Urban spatial data analysis method
